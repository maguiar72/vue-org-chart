Estrutura Organizacional da SETI - TRF3
=======================================

Arquivo unico e autossuficiente (index.html): contem dados, configuracao,
scripts, estilos e fontes embutidos. Nao depende de nenhum arquivo externo
nem de acesso a internet.

Como visualizar
---------------
- Basta abrir "index.html" em qualquer navegador (funciona ate via file://).

Como publicar em um servidor web Linux
--------------------------------------
Apache:
  sudo cp index.html /var/www/html/index.html
  (acesse http://SEU_SERVIDOR/)

Nginx:
  sudo cp index.html /usr/share/nginx/html/index.html
  (acesse http://SEU_SERVIDOR/)

Servidor simples para teste:
  python3 -m http.server 8080
  (acesse http://SEU_SERVIDOR:8080/)

Fonte dos dados
---------------
Estrutura da Secretaria de Tecnologia da Informacao (SETI) do TRF da 3a Regiao,
conforme a Norma de Estrutura das Unidades Administrativas
(Resolucao CATRF3R no 185/2024).

Gerado a partir do projeto vue-org-chart.
