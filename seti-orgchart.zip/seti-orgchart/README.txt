Estrutura Organizacional da SETI - TRF3
=======================================

Arquivo unico e autossuficiente (index.html): contem dados, configuracao,
scripts, estilos e fontes embutidos. Nao depende de arquivos externos nem
de acesso a internet. Inclui a estrutura oficial da SETI e os diretores de
cada unidade.

Como visualizar
---------------
- Abra "index.html" em qualquer navegador (funciona ate via file://).

Como publicar em um servidor web Linux
--------------------------------------
Apache:  sudo cp index.html /var/www/html/index.html
Nginx:   sudo cp index.html /usr/share/nginx/html/index.html
Teste:   python3 -m http.server 8080   (http://SEU_SERVIDOR:8080/)

Fonte dos dados
---------------
Pagina oficial da Estrutura Organizacional do TRF3 (Secretaria de Tecnologia
da Informacao - SETI), Assessoria de Desenvolvimento Integrado e Gestao
Estrategica (ADEG), atualizada em 06/07/2026.

Gerado a partir do projeto vue-org-chart.
